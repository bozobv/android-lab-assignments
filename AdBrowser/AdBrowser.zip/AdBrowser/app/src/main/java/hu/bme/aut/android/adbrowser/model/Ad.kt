package hu.bme.aut.android.adbrowser.model

data class Ad(
    val id: Long?,

    val title: String,

    val description: String,

    val location: String,

    val price: Long
)
