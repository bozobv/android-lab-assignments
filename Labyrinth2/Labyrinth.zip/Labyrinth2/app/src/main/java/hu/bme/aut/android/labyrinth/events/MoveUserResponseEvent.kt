package hu.bme.aut.android.labyrinth.events

class MoveUserResponseEvent(val response: String)