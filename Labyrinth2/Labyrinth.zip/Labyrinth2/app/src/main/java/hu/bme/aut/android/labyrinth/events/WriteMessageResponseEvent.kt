package hu.bme.aut.android.labyrinth.events

class WriteMessageResponseEvent(val response: String)