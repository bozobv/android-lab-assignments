package hu.bme.aut.simpledrawer.model

import android.graphics.Point

class Line(var start: Point? = null, var end: Point? = null) {

}